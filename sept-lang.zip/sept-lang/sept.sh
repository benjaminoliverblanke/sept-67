#!/usr/bin/env bash
# SEPT Language Runner
# Usage: ./sept.sh [file.sept]

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$SCRIPT_DIR/src/sept.py" "$@"
