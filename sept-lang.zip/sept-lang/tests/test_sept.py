#!/usr/bin/env python3
"""
Test suite for SEPT language.
Run: python3 tests/test_sept.py
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from sept import Lexer, Parser, Interpreter, to_s67, from_s67, run_source, SeptError

PASS = "\033[32m✓\033[0m"
FAIL = "\033[31m✗\033[0m"
tests_run = 0
tests_passed = 0


def test(name, fn):
    global tests_run, tests_passed
    tests_run += 1
    try:
        fn()
        print(f"  {PASS} {name}")
        tests_passed += 1
    except Exception as e:
        print(f"  {FAIL} {name}: {e}")


def assert_eq(a, b):
    assert a == b, f"Expected {b!r}, got {a!r}"


def capture_output(source):
    """Run SEPT code and capture printed output."""
    import io
    from contextlib import redirect_stdout
    buf = io.StringIO()
    interp = Interpreter()
    with redirect_stdout(buf):
        run_source(source, interp)
    return buf.getvalue().strip()


print("\n\033[36m⬡ SEPT Language Test Suite\033[0m\n")

# ── SEPTEM-67 Core ────────────────────────────────────
print("\033[33m[1] SEPTEM-67 Core\033[0m")
test("to_s67(0) == '0'",         lambda: assert_eq(to_s67(0), "0"))
test("to_s67(1) == '1'",         lambda: assert_eq(to_s67(1), "1"))
test("to_s67(9) == '9'",         lambda: assert_eq(to_s67(9), "9"))
test("to_s67(10) == 'A'",        lambda: assert_eq(to_s67(10), "A"))
test("to_s67(35) == 'Z'",        lambda: assert_eq(to_s67(35), "Z"))
test("to_s67(36) == 'a'",        lambda: assert_eq(to_s67(36), "a"))
test("to_s67(61) == 'z'",        lambda: assert_eq(to_s67(61), "z"))
test("to_s67(62) == 'Ω'",        lambda: assert_eq(to_s67(62), "Ω"))
test("to_s67(66) == 'Σ'",        lambda: assert_eq(to_s67(66), "Σ"))
test("to_s67(67) == '10'",       lambda: assert_eq(to_s67(67), "10"))
test("to_s67(1337) == 'JΣ'",     lambda: assert_eq(to_s67(1337), "JΣ"))
test("from_s67('0') == 0",       lambda: assert_eq(from_s67("0"), 0))
test("from_s67('A') == 10",      lambda: assert_eq(from_s67("A"), 10))
test("from_s67('10') == 67",     lambda: assert_eq(from_s67("10"), 67))
test("from_s67('JΣ') == 1337",   lambda: assert_eq(from_s67("JΣ"), 1337))
test("roundtrip 999999",         lambda: assert_eq(from_s67(to_s67(999999)), 999999))
test("roundtrip 0",              lambda: assert_eq(from_s67(to_s67(0)), 0))

# ── Lexer ─────────────────────────────────────────────
print("\n\033[33m[2] Lexer\033[0m")
from sept import Lexer, TT
def lex(src): return Lexer(src).tokenize()
test("Lex decimal",  lambda: assert_eq(lex("42")[0].type, TT["DEC"]))
test("Lex string",   lambda: assert_eq(lex('"hi"')[0].type, TT["STRING"]))
test("Lex S67 lit",  lambda: assert_eq(lex("§1A")[0].type, TT["S67"]))
test("Lex ΔΩ",       lambda: assert_eq(lex("ΔΩ")[0].type, TT["LET"]))
test("Lex Φ",        lambda: assert_eq(lex("Φ")[0].type, TT["PRINT"]))
test("Lex Ω·Δ",      lambda: assert_eq(lex("Ω·Δ")[0].type, TT["TRUE"]))
test("Lex Ω·Φ",      lambda: assert_eq(lex("Ω·Φ")[0].type, TT["FALSE"]))

# ── Interpreter ───────────────────────────────────────
print("\n\033[33m[3] Interpreter\033[0m")
test("Print decimal",   lambda: assert_eq(capture_output('Φ 42'), "42"))
test("Print string",    lambda: assert_eq(capture_output('Φ "hi"'), "hi"))
test("S67 literal",     lambda: assert_eq(capture_output('Φ §A'), "10"))
test("S67 literal 67",  lambda: assert_eq(capture_output('Φ §10'), "67"))
test("Addition",        lambda: assert_eq(capture_output('Φ 3 + 4'), "7"))
test("Subtraction",     lambda: assert_eq(capture_output('Φ 10 - 3'), "7"))
test("Multiplication",  lambda: assert_eq(capture_output('Φ 6 * 7'), "42"))
test("Division",        lambda: assert_eq(capture_output('Φ 10 / 4'), "2.5"))
test("Modulo",          lambda: assert_eq(capture_output('Φ 10 % 3'), "1"))
test("Power",           lambda: assert_eq(capture_output('Φ 2 ^ 8'), "256"))
test("String concat",   lambda: assert_eq(capture_output('Φ "a" + "b"'), "ab"))
test("Let var",         lambda: assert_eq(capture_output('ΔΩ x := 5\nΦ x'), "5"))
test("Reassign var",    lambda: assert_eq(capture_output('ΔΩ x := 5\nx := 10\nΦ x'), "10"))
test("If true",         lambda: assert_eq(capture_output('Δif Ω·Δ { Φ "yes" }'), "yes"))
test("If false",        lambda: assert_eq(capture_output('Δif Ω·Φ { Φ "yes" } Δelse { Φ "no" }'), "no"))
test("Loop count",      lambda: assert_eq(capture_output('ΔΩ s := 0\nΩ67 5 ΣΦ i { s := s + 1 }\nΦ s'), "5"))
test("While loop",      lambda: assert_eq(capture_output('ΔΩ n := 0\nΩΔΩ n < 3 { n := n + 1 }\nΦ n'), "3"))
test("Function def",    lambda: assert_eq(capture_output('ΣΩ f(x) { ΣΣ x * 2 }\nΦ f(5)'), "10"))
test("Recursion",       lambda: assert_eq(capture_output('ΣΩ fak(n) { Δif n <= 1 { ΣΣ 1 }\nΣΣ n * fak(n-1) }\nΦ fak(5)'), "120"))
test("List index",      lambda: assert_eq(capture_output('ΔΩ l := [10, 20, 30]\nΦ l[1]'), "20"))
test("Builtin len",     lambda: assert_eq(capture_output('Φ len("hello")'), "5"))
test("Builtin s67",     lambda: assert_eq(capture_output('Φ s67(1337)'), "JΣ"))
test("Builtin sqrt",    lambda: assert_eq(capture_output('Φ sqrt(9)'), "3"))
test("Builtin abs",     lambda: assert_eq(capture_output('Φ abs(-5)'), "5"))
test("PrintRaw ΦΔ",     lambda: assert_eq(capture_output('ΦΔ 1337'), "JΣ"))
test("Bool true",       lambda: assert_eq(capture_output('Φ Ω·Δ'), "Ω·Δ"))
test("Bool false",      lambda: assert_eq(capture_output('Φ Ω·Φ'), "Ω·Φ"))
test("NOT operator",    lambda: assert_eq(capture_output('Φ ΩΣ Ω·Δ'), "False"))
test("AND operator",    lambda: assert_eq(capture_output('Φ Ω·Δ ΩΔ Ω·Φ'), "False"))
test("OR operator",     lambda: assert_eq(capture_output('Φ Ω·Φ ΩΦ Ω·Δ'), "True"))

# ── Example Files ─────────────────────────────────────
print("\n\033[33m[4] Example Files\033[0m")
examples_dir = os.path.join(os.path.dirname(__file__), '..', 'examples')
for fn in sorted(os.listdir(examples_dir)):
    if fn.endswith('.sept'):
        path = os.path.join(examples_dir, fn)
        def make_test(p):
            def t():
                with open(p, encoding='utf-8') as f:
                    src = f.read()
                import io
                from contextlib import redirect_stdout
                buf = io.StringIO()
                interp = Interpreter()
                with redirect_stdout(buf):
                    run_source(src, interp)
                # Just check it runs without error
            return t
        test(f"Run {fn}", make_test(path))

# ── Summary ───────────────────────────────────────────
print(f"\n\033[36m{'─'*40}\033[0m")
pct = int(tests_passed / tests_run * 100) if tests_run else 0
color = "\033[32m" if pct == 100 else "\033[33m" if pct >= 80 else "\033[31m"
print(f"  Results: {color}{tests_passed}/{tests_run} passed ({pct}%)\033[0m")
if tests_passed == tests_run:
    print("  \033[32m⬡ All tests passed! Galactic!\033[0m")
print()
sys.exit(0 if tests_passed == tests_run else 1)
